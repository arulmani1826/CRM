#!/usr/bin/env python3
"""Lead-visibility patch for the stock CRM org-hierarchy gate.

Problem: crm.permissions.org_hierarchy denies agents every Lead whose
lead_owner != them (form) and filters such rows from lists — hiding
Admin-created leads. Final spec: any agent with Leads-view sees ALL leads.

What it does (idempotent): in _permission_query_conditions()' default
(Sales User) branch, CRM-Lead rows defer to crm_coldcall's module flag —
view enabled returns no filter. Falls back to stock behavior if our app
is missing (try/except). Deal/other branches and explicit hierarchy
trees (in_tree) are untouched. _has_permission() reuses the same
conditions, so one edit fixes both form and list paths.

Stored in crm_coldcall (source of truth). Applied to the container by:
  docker exec crm-frappe-1 bash -c \
    'cd /home/frappe/frappe-bench && ./env/bin/python /workspace/crm_coldcall/crm_patches/apply_org_pool.py'
Re-apply after every fresh bench install / CRM app update (apps/ is ephemeral).
"""
import pathlib

TARGET = pathlib.Path(
    "/home/frappe/frappe-bench/apps/crm/crm/permissions/org_hierarchy.py"
)
ANCHOR = "\t# Sales User default: own records and records directly assigned to them\n"
OLD_Q1 = "\tq1 = DT[owner_field] == user\n"
# Superseded v1 pool block (removed on upgrade).
OLD_POOL = (
    "\t# Sales User default: own records, records directly assigned to them,\n"
    "\t# and the unassigned pool (no owner yet) so Admin-created leads stay\n"
    "\t# visible to agents with module access (crm_coldcall RBAC). Lead-only;\n"
    "\t# explicit hierarchy trees (in_tree branch above) are untouched.\n"
    "\tq1 = DT[owner_field] == user\n"
    "\tif doctype == \"CRM Lead\":\n"
    "\t\tq1 = q1 | DT[owner_field].isnull() | (DT[owner_field] == \"\")\n"
)
NEW_BLOCK = (
    "\t# Sales User default: own records and records directly assigned to them.\n"
    "\t# crm_coldcall RBAC is authoritative for LEAD visibility (Lead-only):\n"
    "\t# agents with Leads-view see every lead; the coldcall app enforces the\n"
    "\t# module flag plus create/delete itself. Falls back to stock scoping\n"
    "\t# when crm_coldcall is absent. Hierarchy trees (in_tree) untouched.\n"
    "\tq1 = DT[owner_field] == user\n"
    "\tif doctype == \"CRM Lead\":\n"
    "\t\ttry:\n"
    "\t\t\tfrom crm_coldcall.api.agent_access import module_enabled as _cc_leads_view\n"
    "\t\t\tif _cc_leads_view(user, \"leads\"):\n"
    "\t\t\t\treturn \"\"\n"
    "\t\texcept Exception:\n"
    "\t\t\tpass\n"
)


def main():
    src = TARGET.read_text()
    changed = False
    if "crm_coldcall RBAC is authoritative" not in src:
        if OLD_POOL in src:
            src = src.replace(OLD_POOL, NEW_BLOCK, 1)
        elif ANCHOR + OLD_Q1 in src:
            src = src.replace(ANCHOR + OLD_Q1, NEW_BLOCK, 1)
        else:
            raise SystemExit("anchor not found - CRM org_hierarchy.py changed upstream")
        changed = True
    # _has_permission() feeds the conditions object into qb.where(): a plain
    # "" (no filter) crashes pypika. Short-circuit to allowed instead —
    # the coldcall layer already enforced the module flag.
    hp_old = ("\tconditions = _permission_query_conditions(user, doctype)\n"
              "\tDT = frappe.qb.DocType(doctype)\n")
    hp_new = ("\tconditions = _permission_query_conditions(user, doctype)\n"
              "\tif isinstance(conditions, str):\n"
              "\t\t# No row filter (crm_coldcall RBAC decided): doc passes this layer.\n"
              "\t\treturn True\n"
              "\tDT = frappe.qb.DocType(doctype)\n")
    if "No row filter (crm_coldcall RBAC decided)" not in src:
        if hp_old not in src:
            raise SystemExit("has_permission anchor missing - CRM file changed upstream")
        src = src.replace(hp_old, hp_new, 1)
        changed = True
    TARGET.write_text(src)
    print("lead-visibility patch applied" if changed else "lead-visibility patch already applied")


if __name__ == "__main__":
    main()
